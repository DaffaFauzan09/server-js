const suhuudara = require("./controller-suhuudara");
const suhuair = require("./controller-suhuair");
const tds = require("./controller-tds");
const ph = require("./controller-ph");
const turbidity = require("./controller-turbidity");

module.exports = {
  suhuudara,
  suhuair,
  tds,
  ph,
  turbidity,
};
