module.exports = {
  multipleStatement: true,
  host: "127.0.0.1",
  user: "root",
  password: "raspberry",
  database: "sensor_esp32",
};
